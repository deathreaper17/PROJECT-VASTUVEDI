import { FaPhone, FaEnvelope, FaBuilding, FaPaintBrush, FaFileContract, FaClipboardCheck } from 'react-icons/fa';
import './App.css';

function App() {
  const portfolioImages = [
    {
      url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800',
      title: 'Modern House Design',
      category: 'Architecture'
    },
    {
      url: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=800',
      title: 'Luxury Interior',
      category: 'Interior Design'
    },
    {
      url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&q=80&w=800',
      title: 'Contemporary Living Room',
      category: 'Interior Design'
    },
    {
      url: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&q=80&w=800',
      title: 'Modern Architecture',
      category: 'Architecture'
    },
    {
      url: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=800',
      title: 'Elegant Kitchen Design',
      category: 'Interior Design'
    },
    {
      url: 'https://images.unsplash.com/photo-1613545325278-f24b0cae1224?auto=format&fit=crop&q=80&w=800',
      title: 'Commercial Space',
      category: 'Turnkey Project'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <header className="bg-gray-900 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl font-bold mb-4">VASTUVEDU</h1>
          <p className="text-xl">Creating Spaces That Inspire</p>
        </div>
      </header>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <ServiceCard
              icon={<FaBuilding className="text-4xl" />}
              title="Architecture"
              description="Innovative architectural designs that blend form and function"
            />
            <ServiceCard
              icon={<FaPaintBrush className="text-4xl" />}
              title="Interiors"
              description="Beautiful interior designs that transform spaces"
            />
            <ServiceCard
              icon={<FaClipboardCheck className="text-4xl" />}
              title="Turnkey Projects"
              description="End-to-end project management and execution"
            />
            <ServiceCard
              icon={<FaFileContract className="text-4xl" />}
              title="Sanctioning"
              description="Professional handling of all legal and regulatory approvals"
            />
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Portfolio</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {portfolioImages.map((image, index) => (
              <div key={index} className="group relative overflow-hidden rounded-lg shadow-lg">
                <img
                  src={image.url}
                  alt={image.title}
                  className="w-full h-64 object-cover transform transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <h3 className="text-white font-semibold text-lg">{image.title}</h3>
                  <p className="text-gray-200 text-sm">{image.category}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-gray-100 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Contact Us</h2>
          <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8">
            <div className="space-y-6">
              <ContactInfo
                icon={<FaBuilding className="text-2xl text-gray-600" />}
                title="Name"
                info="Tanya Singhal"
              />
              <ContactInfo
                icon={<FaPhone className="text-2xl text-gray-600" />}
                title="Phone"
                info="7302255916"
              />
              <ContactInfo
                icon={<FaEnvelope className="text-2xl text-gray-600" />}
                title="Email"
                info="tanyasinghal98@gmail.com"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>© 2024 VASTUVEDU. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function ServiceCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow">
      <div className="text-gray-600 mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function ContactInfo({ icon, title, info }: { icon: React.ReactNode; title: string; info: string }) {
  return (
    <div className="flex items-center space-x-4">
      {icon}
      <div>
        <h3 className="font-semibold">{title}</h3>
        <p className="text-gray-600">{info}</p>
      </div>
    </div>
  );
}

export default App;